const ToDoList = [
  {
    name: 'make dinner',
    dueDate: '2025-06-05'
  },
  {
    name: 'drink water',
    dueDate: '2025-06-05'
  }
];

showToDoList();

function showToDoList(){
  let ToDoListHTML = '';

  ToDoList.forEach((TodoObject) => {
    const {name, dueDate} = TodoObject;
    const html = `
      <div>${name}</div>
      <div>${dueDate}</div>
      <button class="delete-dodo-button js-delete-todo-button">Delete</button>
    `;
    ToDoListHTML += html;
  });
  document.querySelector('.js-todo-list').innerHTML = ToDoListHTML;

  document.querySelectorAll('.js-delete-todo-button').forEach((deleteButton, index) => {
    deleteButton.addEventListener('click', () => {
      ToDoList.splice(index, 1);
      showToDoList();
    });
  });
}

document.querySelector('.js-add-todo-button').addEventListener('click', () => {
  addToDo();
});

function addToDo(){
  const inputElement = document.querySelector('.js-name-input');
  const name = inputElement.value;

  const dateInputElement = document.querySelector('.js-due-date-input');
  const dueDate = dateInputElement.value;

  ToDoList.push(
    {
      name,
      dueDate
    }
  );
  showToDoList();
  inputElement.value = '';
  dateInputElement.value = '';
}
